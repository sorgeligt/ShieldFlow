package com.sorgeligt.shieldflow.core.time

public interface TimeProvider {
    public fun nowMillis(): Long
}
