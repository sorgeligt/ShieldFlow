package com.sorgeligt.shieldflow.assertion.handler

public fun interface AssertionEventLogger {
    public fun log(event: AssertionEvent)
}
