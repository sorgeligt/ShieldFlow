package com.sorgeligt.shieldflow.network.adapters

public interface TelemetryNetworkEventsAdapter {
    public fun getPaths(): List<String>
}
