plugins {
    alias(libs.plugins.kotlinJvm) apply false
}
